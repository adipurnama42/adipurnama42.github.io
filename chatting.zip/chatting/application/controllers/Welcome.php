<?php
defined('BASEPATH') or exit('No direct script access allowed');

use Firebase\Firebase;

class Welcome extends CI_Controller
{
	public function index()
	{
		$fb = Firebase::initialize('https://chatting-adaa7-default-rtdb.firebaseio.com', 'Fbkrlcf2E5ip7wfOsMibHwJV9cI0kWvBrxOmO66Q');

		$a = $fb->get('/chats');
		$b = json_encode($a);

		// $arr = []; //create empty array
		// foreach ($a as $record) {
		// 	$arr[] = array(
		// 		'date' => $record->date,
		// 		'from' => $record->from,
		// 		'message' => $record->message,
		// 		'to' => $record->to
		// 	);
		// }
		// print_r($a);
		$arr = array();
		foreach ($a as $dt) {
			echo $dt['date'];
			echo "<hr>";
			echo $dt['from'];
		}


		// echo print_r($a);
		// $data = array();
		// foreach ($a as $key) {
		// 	foreach ($key as $data) {
		// 		echo $data;
		// 	}
		// 	// echo print_r($key);
		// }
	}
	public function get_data()
	{
		$fb = Firebase::initialize('https://chatting-adaa7-default-rtdb.firebaseio.com', 'Fbkrlcf2E5ip7wfOsMibHwJV9cI0kWvBrxOmO66Q');

		$a = $fb->get('/chats');
		echo json_encode($a);
	}

	public function add_data()
	{
		$fb = Firebase::initialize('https://chatting-adaa7-default-rtdb.firebaseio.com', 'Fbkrlcf2E5ip7wfOsMibHwJV9cI0kWvBrxOmO66Q');
		$d = [
			"date" => "10-12-2022 12:01:00",
			"from" => "atom",
			"message" => "halo juga",
			"to" => "adi",
		];
		$a = $fb->push('/chats', $d);
		echo json_encode($a);
	}
	public function update_data()
	{
		$key = $this->input->get("key");
		$fb = Firebase::initialize('https://chatting-adaa7-default-rtdb.firebaseio.com', 'Fbkrlcf2E5ip7wfOsMibHwJV9cI0kWvBrxOmO66Q');
		$d = [
			"notif" => "1",
			"tipe" => "0",
		];
		$a = $fb->update('/data/' . $key, $d);
		echo json_encode($a);
	}
	public function delete_data()
	{
		$key = $this->input->get("key");
		$fb = Firebase::initialize('https://chatting-adaa7-default-rtdb.firebaseio.com', 'Fbkrlcf2E5ip7wfOsMibHwJV9cI0kWvBrxOmO66Q');
		$d = [
			"notif" => "1",
			"tipe" => "0",
		];
		$a = $fb->delete('/data/' . $key, $d);
		echo json_encode($a);
	}
}